#ifndef _Arduino_Serial_h_
#define _Arduino_Serial_h_

#include <Project.h>
#include "UARTClass.h"

bool enableUSBCDC();
void USBUART_FunctionAttach();
void UART_FunctionAttach();

#endif

