/*******************************************************************************
* File Name: isr_CrankTriggerCapture.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_isr_CrankTriggerCapture_H)
#define CY_ISR_isr_CrankTriggerCapture_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void isr_CrankTriggerCapture_Start(void);
void isr_CrankTriggerCapture_StartEx(cyisraddress address);
void isr_CrankTriggerCapture_Stop(void);

CY_ISR_PROTO(isr_CrankTriggerCapture_Interrupt);

void isr_CrankTriggerCapture_SetVector(cyisraddress address);
cyisraddress isr_CrankTriggerCapture_GetVector(void);

void isr_CrankTriggerCapture_SetPriority(uint8 priority);
uint8 isr_CrankTriggerCapture_GetPriority(void);

void isr_CrankTriggerCapture_Enable(void);
uint8 isr_CrankTriggerCapture_GetState(void);
void isr_CrankTriggerCapture_Disable(void);

void isr_CrankTriggerCapture_SetPending(void);
void isr_CrankTriggerCapture_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the isr_CrankTriggerCapture ISR. */
#define isr_CrankTriggerCapture_INTC_VECTOR            ((reg32 *) isr_CrankTriggerCapture__INTC_VECT)

/* Address of the isr_CrankTriggerCapture ISR priority. */
#define isr_CrankTriggerCapture_INTC_PRIOR             ((reg8 *) isr_CrankTriggerCapture__INTC_PRIOR_REG)

/* Priority of the isr_CrankTriggerCapture interrupt. */
#define isr_CrankTriggerCapture_INTC_PRIOR_NUMBER      isr_CrankTriggerCapture__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable isr_CrankTriggerCapture interrupt. */
#define isr_CrankTriggerCapture_INTC_SET_EN            ((reg32 *) isr_CrankTriggerCapture__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the isr_CrankTriggerCapture interrupt. */
#define isr_CrankTriggerCapture_INTC_CLR_EN            ((reg32 *) isr_CrankTriggerCapture__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the isr_CrankTriggerCapture interrupt state to pending. */
#define isr_CrankTriggerCapture_INTC_SET_PD            ((reg32 *) isr_CrankTriggerCapture__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the isr_CrankTriggerCapture interrupt. */
#define isr_CrankTriggerCapture_INTC_CLR_PD            ((reg32 *) isr_CrankTriggerCapture__INTC_CLR_PD_REG)


#endif /* CY_ISR_isr_CrankTriggerCapture_H */


/* [] END OF FILE */
