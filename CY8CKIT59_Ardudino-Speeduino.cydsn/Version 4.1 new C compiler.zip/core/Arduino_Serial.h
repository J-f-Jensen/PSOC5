#ifndef _Arduino_Serial_h_
#define _Arduino_Serial_h_

#include <project.h>
#include "UARTClass.h"

bool enableUSBCDC();
void USBUART_FunctionAttach();
void UART_FunctionAttach();

#endif

