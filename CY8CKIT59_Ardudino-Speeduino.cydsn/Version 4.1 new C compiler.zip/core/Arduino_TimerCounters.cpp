/*******************************************************
 * This file includes timers and counters needed for Speeduino
 * but can be used for other Arduino PSOC5 projects if you find 
 * it use full
 *
 ******************************************************/

#include "Arduino_TimerCounters.h"



/* [] END OF FILE */





